from django.contrib import admin
from .models import DashboardStat

admin.site.register(DashboardStat)
